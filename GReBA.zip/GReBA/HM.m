function [Phm] = HM(KH,GAR_man,GAR_nac)

Pmaxhm=KH(1);
Kshmnac=KH(2);
Kihmman=KH(3);
P_nonhm=Pmaxhm.*GAR_nac./(GAR_nac+Kshmnac).*Kihmman./(Kihmman+GAR_man);
Phm=100-P_nonhm;

end

