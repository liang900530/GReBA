# GReBA
 

**Glycosylation residue balance analysis (GReBA) is model for the glycosylation of IgG produced CHO cells with the culture feeding with different carbon sources

### Last Update:
23.08.2019 https://github.com/liang900530/GReBA

### Download and installation
Please refer to Installation Guide for MATLAB

### Using the model
The model starts with the file GReBA.m

### Acknowledgements
This research was supported by the Chinese Scholarship Council, by the project SmartFD sponsored by the Sweden's Innovation Agency VINNOVA (diaries nr. 2016-02398), by GE Healthcare Life Science and by the Competence Centre for Advanced BioProduction by Continuous Processing, AdBIOPRO, funded by the Sweden's Innovation Agency VINNOVA (diaries nr. 2016-05181).
