

function [x,e] =MNtoG(x1,x2,y,x0,xl)

fun=@(p) p(1).*x1./(p(2)+x1+x2.*p(2)./p(3))+p(4).*x2./(p(5)+x2+x1.*p(5)./p(6))-y;
options = optimoptions('lsqnonlin','MaxFunctionEvaluations',99999,'MaxIterations',9999);

[x,e] = lsqnonlin(fun,x0,xl,[],options);

end

