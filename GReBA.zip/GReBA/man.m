%The synthesis of GCP_Mannose, which are from glc,man and gal respectively

%The maxium reaction rate:
function [GCPman] = man(Cman, Cgal, Cglc, Kman)
GCPmanmaxglc=Kman(1);
GCPmanmaxman=Kman(2);
GCPmanmaxgal=Kman(3);

%The saturation kinetic parameter
Ksmanglc=Kman(6);
Ksmanman=Kman(7);
Ksmangal=Kman(8);

%The Inhibition kinetic parameter
Kimanglcman=Kman(11);
Kimanglcgal=Kman(12);
Kimanmanglc=Kman(13);
Kimanmangal=Kman(14);
Kimangalglc=Kman(15);
Kimangalman=Kman(16);
%Kimanglcglc=Kman(17);
%Kimanmanman=Kman(18);
%Kimangalgal=Kman(19);

%GCP_mannose from glucose. Mannose and galacose have the inhibition effect:
GCPman_glc=GCPmanmaxglc.*Cglc./(Cglc+Ksmanglc); 
%GCP_mannose from mannose. Glucose and galacose have the inhibition effect:
GCPman_man=GCPmanmaxman.*Cman./(Cman+Ksmanman+Cgal.*Ksmanman./Kimanmangal);
%GCP_mannose from galactose. Mannose and glucose have the inhibition effect:
GCPman_gal=GCPmanmaxgal.*Cgal./(Cgal+Ksmangal+Cman.*Ksmangal./Kimangalman);
%Total amount of GCP_mannose
GCPman=GCPman_glc+GCPman_man+GCPman_gal;

end