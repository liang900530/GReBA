%GReBA, Glycosylation Model Version 3 
%Liang Zhang, KTH, April, 2019
%This model is composed of three parts: High Mannose identification, Fucosylation identification, and galactosylation identification.
%The experimental data is splitted into a training set and a validation
%set. The validation set includes the following culture conditions: 15 mM mannose, 15 mM galactose, and 15 mM mannose + 15 mM galactose. 
%while the training set included all the other culture conditions. 

clear all

%% Training
% parameter estimation for the first part
load('Kinetic') % it will be updated during the training
%The concentration of galactose, mannose, and galactose
load('Sugar')
Sugar(19:24,:)=[]; %remove only feeding glucose
Sugar(3:4,:)=[];Sugar(7:8,:)=[]; Sugar(11:12,:)=[];%remove the validation set for training

Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

%the glycosylation patterns from experimental data
load('Glyco')
Glyco(19:24,:)=[]; %remove only feeding glucose
Glyco(3:4,:)=[];Glyco(7:8,:)=[]; Glyco(11:12,:)=[];%remove the validation set for training

RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
Run=Glyco(:,12);

Kinetic=Para(Sugar,Glyco,Kinetic);
%Kinetic=ParaGlc(Sugar,Glyco,Kinetic);   %for only glucose

% The predicted values of GARs from the first part of the model after training
Kfuc=Kinetic.Kfuc;
GAR_fuc=fuc(Cman, Cgal, Cglc, Kfuc);

Kman=Kinetic.Kman;
GAR_man=man(Cman, Cgal, Cglc, Kman);

Knac=Kinetic.Knac;
GAR_nac=nac(Cman, Cgal, Cglc, Knac);

%The predicted proportion of high mannsoe glycoform
KH=Kinetic.KH;
Phm=HM(KH,GAR_man,GAR_nac);
P_nonhm=100-Phm;
Rhm=Glyco(:,7)+Glyco(:,8);

%Unassigned glycoform
Unas=Run;

%The fucosylated glycans and afucosylated glycans, should exclude the
%assigned
PGF=(P_nonhm-Unas).*GAR_fuc/100;
PG=(P_nonhm-Unas).*(1-GAR_fuc/100);

% parameter estimation for the second part
Kinetic=Para2(Sugar,Glyco,Kinetic);
%Kinetic=ParaGlc2(Sugar,Glyco,Kinetic); %for only glucose

% The second part of the model

%%The distrabution of G0F,G1F,G2F
KG=Kinetic.KG;
[PG0F,PG1F,PG2F,PG0,PG1]=Galacto(Cman, Cgal, Cglc, KG, PGF,PG);


%% plot glycosylation predictions
Glycoplot(Kfuc, Kman, Knac, KH, KG)



%% Validation

load('Sugar')
Sugar=[Sugar(3,:);Sugar(10,:);Sugar(15,:)]; % the validation feeding conditions
Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

load('Glyco')
Glyco=[Glyco(3,:);Glyco(10,:);Glyco(15,:)]; %remove only feeding glucose
RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
Run=Glyco(:,12);

% The predicted values of GAR from the first part of the model
Kfuc=Kinetic.Kfuc;
GAR_fuc=fuc(Cman, Cgal, Cglc, Kfuc);

Kman=Kinetic.Kman;
GAR_man=man(Cman, Cgal, Cglc, Kman);

Knac=Kinetic.Knac;
GAR_nac=nac(Cman, Cgal, Cglc, Knac);

%The predicted proportion of high mannsoe glycoform
KH=Kinetic.KH;
Phm=HM(KH,GAR_man,GAR_nac);
P_nonhm=100-Phm;
Rhm=Glyco(:,7)+Glyco(:,8);

%Unassigned glycoform
Unas=Run;

%The fucosylated glycans and afucosylated glycans, should exclude the
%assigned
PGF=(P_nonhm-Unas).*GAR_fuc/100;
PG=(P_nonhm-Unas).*(1-GAR_fuc/100);

%The distrabution of G0F,G1F,G2F
KG=Kinetic.KG;
[PG0F,PG1F,PG2F,PG0,PG1]=Galacto(Cman, Cgal, Cglc, KG, PGF,PG);

%the error between the prediction and the experimental data
EG1F=RG1F-PG1F';   EG2F=RG2F-PG2F';   EG0F=RG0F-PG0F';
EG0=RG0-PG0';   EG1=RG1-PG1';   EGF=RGF-PGF;   Ehm=Rhm-Phm;
EGlyP=abs([Ehm,EG0F,EG1F,EG2F,EG0,EG1,EGF])
