function [Kinetic] = ParaGlc(Sugar,Glyco,Kinetic)
%The concentration of galactose, mannose, and galactose

    Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
    Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
    Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

    %the glycosylation patterns from experimental data

    RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
    RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
    RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
    RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
    Run=Glyco(:,12);



    %% Parameter identificaiton
    fuc=RGF./(RGF+RG0+RG1)*100;
    nac=(RG0F+RG1F+RG2F+RG0+RG1+Run).*4+Rhm.*2+RG0FNN.*5+(RG0FN+RG0N).*3;
    man=(RG0F+RG1F+RG2F+RG0+RG1+Run+RG0FNN+RG0FN+RG0N).*3+RM5.*5+RM6.*6;

    % fuc
    e=9999;
    Kfuc=[1,1];
    for i=1:100
        x0=rand(1,2).*100;
        xl=[max(fuc(1:6)),0];
        [Kfuc0,e0]=GtoG(Cglc,fuc,x0,xl)
        if e0<e
            e=e0;
            Kfuc=Kfuc0;
        end     
    end
    Kinetic.Kfuc(1)=Kfuc(1);
    Kinetic.Kfuc(6)=Kfuc(2);

    % nac
    e=9999;
    Knac=[1,1];
    for i=1:100
        x0=rand(1,2).*400;
        xl=[max(nac(1:6)),0];
        [Knac0,e0]=GtoG(Cglc,nac,x0,xl)
        if e0<e
            e=e0;
            Knac=Knac0;
        end     
    end
    Kinetic.Knac(1)=Knac(1);
    Kinetic.Knac(6)=Knac(2);

    % man
    e=9999;
    Kman=[1,1];
    for i=1:100
        x0=rand(1,2).*300;
        xl=[max(man(1:6)),0];
        [Kman0,e0]=GtoG(Cglc,man,x0,xl)
        if e0<e
            e=e0;
            Kman=Kman0;
        end     
    end
    Kinetic.Kman(1)=Kman(1);
    Kinetic.Kman(6)=Kman(2);


    % High mannose

    e=9999;
    KH=[1,1,1];
    for i=1:10
        x0=rand(1,6).*3000;
        xl=[max(100-Rhm),0,0]
        [KH0,e0]=HMPI(nac,man,100-Rhm,x0,xl)
        if e0<e
            e=e0;
            KH=KH0;
        end
    end
    Kinetic.KH(1)=KH(1);
    Kinetic.KH(2)=KH(2);
    Kinetic.KH(3)=KH(3);
end











