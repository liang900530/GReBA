%Glycosylation Model Parameter identification 
%Liang Zhang, KTH, April, 2019
%This function is used for the parameter identification for the second part
function [Kinetic] = ParaGlc2(Sugar,Glyco,Kinetic)

    %The concentration of galactose, mannose, and galactose
    
    Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
    Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
    Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

    %the glycosylation patterns from experimental data
    
    RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
    RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
    RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
    RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
    Run=Glyco(:,12);

    %The value of GCP from the first part of the model

    %% Parameter identificaiton
    % for PG12F
    e=9999;
    KG12F=[1,1];
    for i=1:10
        x0=rand(1,2).*50;
        xl=[max(RG12F(1:6)),0];
        [KG12F0,e0]=GtoG(Cglc,RG12F,x0,xl)
        if e0<e
            e=e0;
            KG12F=KG12F0;
        end
    end
    Kinetic.KG(11)=KG12F(1);
    Kinetic.KG(12)=KG12F(2);
  
    % for PG2F
    e=9999;
    KG2F=[1,1];
    for i=1:10
        x0=rand(1,2).*5;
        xl=[max(RG2F(1:6)),0];
        [KG2F0,e0]=GtoG(Cglc,RG2F,x0,xl)
        if e0<e
            e=e0;
            KG2F=KG2F0;
        end
    end
    Kinetic.KG(26)=KG2F(1);
    Kinetic.KG(27)=KG2F(2);
    
    
    
    % for PG1
    e=9999;
    KG1=[1,1];
    for i=1:10
        x0=rand(1,2).*1;
        xl=[max(RG1(1:6)),0];
        [KG10,e0]=GtoG(Cglc,RG1,x0,xl)
        if e0<e
            e=e0;
            KG1=KG10;
        end
    end
    Kinetic.KG(41)=KG1(1);
    Kinetic.KG(42)=KG1(2);
    
    
end


