function [PG0F,PG1F,PG2F,PG0,PG1] = Galacto(Cman, Cgal, Cglc, KG,PGF,PG)

Vg1fmaxman=KG(1);
KSg1fman=KG(2);
KIg1fmanglc=KG(3);
KIg1fmangal=KG(4);
%KIg1fmanman=KG(5);

Vg1fmaxgal=KG(6);
KSg1fgal=KG(7);
KIg1fgalglc=KG(8);
KIg1fgalman=KG(9);
%KIg1fgalgal=KG(10);

Vg1fmaxglc=KG(11);
KSg1fglc=KG(12);
KIg1fglcman=KG(13);
KIg1fglcgal=KG(14);
%KIg1fglcglc=KG(15);

Vg2fmaxman=KG(16);
KSg2fman=KG(17);
KIg2fmanglc=KG(18);
KIg2fmangal=KG(19);
%KIg2fmanman=KG(20);

Vg2fmaxgal=KG(21);
KSg2fgal=KG(22);
KIg2fgalglc=KG(23);
KIg2fgalman=KG(24);
%KIg2fgalgal=KG(25);

Vg2fmaxglc=KG(26);
KSg2fglc=KG(27);
KIg2fglcman=KG(28);
KIg2fglcgal=KG(29);
%KIg2fglcglc=KG(30);

Vg1maxman=KG(31);
KSg1man=KG(32);
KIg1manglc=KG(33);
KIg1mangal=KG(34);
%KIg1manman=KG(35);

Vg1maxgal=KG(36);
KSg1gal=KG(37);
KIg1galglc=KG(38);
KIg1galman=KG(39);
%KIg1galgal=KG(40);

Vg1maxglc=KG(41);
KSg1glc=KG(42);
KIg1glcman=KG(43);
KIg1glcgal=KG(44);
%KIg1glcglc=KG(45);

n=length(Cman);

for i=1:n
    PG12Fman(i)=Vg1fmaxman.*(Cman(i)/(Cman(i)+Cgal(i).*KSg1fman./KIg1fmangal+KSg1fman));
    PG12Fgal(i)=Vg1fmaxgal.*(Cgal(i)/(Cgal(i)+Cman(i).*KSg1fgal./KIg1fgalman+KSg1fgal));
    PG12Fglc(i)=Vg1fmaxglc.*(Cglc(i)/(Cglc(i)+KSg1fglc));
    PG12F(i)=PG12Fman(i)+PG12Fgal(i)+PG12Fglc(i);
   
    PG2Fman(i)=Vg2fmaxman.*(Cman(i)/(Cman(i)+Cgal(i).*KSg2fman./KIg2fmangal+KSg2fman));
    PG2Fgal(i)=Vg2fmaxgal.*(Cgal(i)/(Cgal(i)+Cman(i).*KSg2fgal./KIg2fgalman+KSg2fgal));
    PG2Fglc(i)=Vg2fmaxglc.*(Cglc(i)/(Cglc(i)+KSg2fglc));
    PG2F(i)=PG2Fman(i)+PG2Fgal(i)+PG2Fglc(i);
    
    PG1F(i)=PG12F(i)-PG2F(i);
    PG0F(i)=PGF(i)-PG1F(i)-PG2F(i);
    
    PG1man(i)=Vg1maxman.*(Cman(i)/(Cman(i)+Cgal(i).*KSg1man./KIg1mangal+KSg1man));
    PG1gal(i)=Vg1maxgal.*(Cgal(i)/(Cgal(i)+Cman(i).*KSg1gal./KIg1galman+KSg1gal));
    PG1glc(i)=Vg1maxglc.*(Cglc(i)/(Cglc(i)+KSg1glc));
    PG1(i)=PG1man(i)+PG1gal(i)+PG1glc(i);
    
    PG0(i)=PG(i)-PG1(i);
    
    
end


end

