function [x,e] =GtoG(x,y,x0,xl)

fun=@(p) p(1).*x./(p(2)+x)-y;
options = optimoptions('lsqnonlin','Display','iter');

[x,e] = lsqnonlin(fun,x0,xl);

end