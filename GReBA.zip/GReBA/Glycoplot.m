%Glycoplot
function [] = Glycoplot(Kfuc, Kman, Knac, KH, KG)

cman=0:1:25;
cgal=0:1:25;
Cglc=0;


for i=1:26
    Cman=cman(i);
    
    for j=1:26
        Cgal=cgal(j);
 
        GCPfuc=fuc(Cman, Cgal, Cglc, Kfuc);
        GAR_man=man(Cman, Cgal, Cglc, Kman);
        GAR_nac=nac(Cman, Cgal, Cglc, Knac);

        Phm(i,j)=HM(KH,GAR_man,GAR_nac);
        P_nonhm(i,j)=100-Phm(i,j);
       
        %Unassigned glycoform
        Unas=3.6;

        %The fucosylated glycans and afucosylated glycans, should exclude the
        %assigned

        
        PGF(i,j)=(P_nonhm(i,j)-Unas).*GCPfuc/100;
        PG(i,j)=(P_nonhm(i,j)-Unas).*(1-GCPfuc/100);
        [PG0F(i,j),PG1F(i,j),PG2F(i,j),PG0(i,j),PG1(i,j)]=Galacto(Cman, Cgal, Cglc, KG, PGF(i,j),PG(i,j));
      
    end
    
    
end

Cman=0:1:25;
Cgal=0:1:25;

[X,Y]=meshgrid(Cman,Cgal);
MPG1F=mesh (Cman,Cgal,PG1F');
set(MPG1F,'EdgeColor','r','MarkerEdgecolor','r','MarkerFacecolor','r')
alpha(1)
hold on

MPG0F=mesh (Cman,Cgal,PG0F');
set(MPG0F,'EdgeColor',[0.05,0.5,0.5],'MarkerEdgecolor',[0.05,0.5,0.5],'MarkerFacecolor',[0.05,0.5,0.5])
alpha(0)
hold on
MPG2F=mesh (Cman,Cgal,PG2F');
legend('G1F','G0F','G2F')
alpha(0)
xlabel('Concentration of mannose, mM')
ylabel('Concentration of galactose, mM')
zlabel('Percentage of glycans,%')
hold on


end