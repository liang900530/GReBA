%The synthesis of GCP_GlcNAc, which are from glc,man and gal respectively

%The maxium reaction rate:
function [GCPnac] = nac(Cman, Cgal, Cglc, Knac)
GCPnacmaxglc=Knac(1);
GCPnacmaxman=Knac(2);
GCPnacmaxgal=Knac(3);

%The saturation kinetic parameter
Ksnacglc=Knac(6);
Ksnacman=Knac(7);
Ksnacgal=Knac(8);

%The Inhibition kinetic parameter
Kinacglcman=Knac(11);
Kinacglcgal=Knac(12);
Kinacmanglc=Knac(13);
Kinacmangal=Knac(14);
Kinacgalglc=Knac(15);
Kinacgalman=Knac(16);
%Kinacglcglc=Knac(17);
%Kinacmanman=Knac(18);
%Kinacgalgal=Knac(19);


%GCP_GlcNAc from glucose. Mannose and galacose have the inhibition effect:
GCPnac_glc=GCPnacmaxglc.*Cglc./(Cglc+Ksnacglc); 
%GCP_GlcNAc from mannose. Glucose and galacose have the inhibition effect:
GCPnac_man=GCPnacmaxman.*Cman./(Cman+Ksnacman+Cgal.*Ksnacman./Kinacmangal);
%GCP_GlcNAc from galactose. Mannose and glucose have the inhibition effect:
GCPnac_gal=GCPnacmaxgal.*Cgal./(Cgal+Ksnacgal+Cman.*Ksnacgal./Kinacgalman);
%Total amount of GCP_GlcNAc
GCPnac=GCPnac_glc+GCPnac_man+GCPnac_gal;
end
