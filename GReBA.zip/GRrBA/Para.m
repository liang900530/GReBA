%Glycosylation Model Parameter identification 
%Liang Zhang, KTH, April, 2019
%This function is used for the parameter identification
function [Kinetic] = Para(Sugar,Glyco,Kinetic)

    %The concentration of galactose, mannose, and galactose
    Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
    Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
    Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

    %the glycosylation patterns from experimental data
    RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
    RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
    RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
    RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
    Run=Glyco(:,12);


    %% Parameter identificaiton
    %The value of GCP from the first part of the model
    fuc=RGF./(RGF+RG0+RG1)*100;
    nac=(RG0F+RG1F+RG2F+RG0+RG1+Run).*4+Rhm.*2+RG0FNN.*5+(RG0FN+RG0N).*3;
    man=(RG0F+RG1F+RG2F+RG0+RG1+Run+RG0FNN+RG0FN+RG0N).*3+RM5.*5+RM6.*6;

    % fuc
    e=9999;
    Kfuc=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*100;
        xl=[max(fuc(1:6)),0,0,max(fuc(7:12)),0,0];
        [Kfuc0,e0]=MNtoG(Cman,Cgal,fuc,x0,xl)
        if e0<e
            e=e0;
            Kfuc=Kfuc0;
        end
    end
    Kinetic.Kfuc(2)=Kfuc(1);
    Kinetic.Kfuc(7)=Kfuc(2);
    Kinetic.Kfuc(14)=Kfuc(3);
    Kinetic.Kfuc(3)=Kfuc(4);
    Kinetic.Kfuc(8)=Kfuc(5);
    Kinetic.Kfuc(16)=Kfuc(6);


    % nac
    e=9999;
    Knac=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*400;
        xl=[max(nac(1:6)),0,0,max(nac(7:12)),0,0];
        [Knac0,e0]=MNtoG(Cman,Cgal,nac,x0,xl)
        if e0<e
            e=e0;
            Knac=Knac0;
        end
    end
    Kinetic.Knac(2)=Knac(1);
    Kinetic.Knac(7)=Knac(2);
    Kinetic.Knac(14)=Knac(3);
    Kinetic.Knac(3)=Knac(4);
    Kinetic.Knac(8)=Knac(5);
    Kinetic.Knac(16)=Knac(6);

    % man
    e=9999;
    Kman=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*300;
        xl=[max(man(1:6)),0,0,max(man(7:12)),0,0];
        [Kman0,e0]=MNtoG(Cman,Cgal,man,x0,xl);
        if e0<e
            e=e0;
            Kman=Kman0;
        end
    end
    Kinetic.Kman(2)=Kman(1);
    Kinetic.Kman(7)=Kman(2);
    Kinetic.Kman(14)=Kman(3);
    Kinetic.Kman(3)=Kman(4);
    Kinetic.Kman(8)=Kman(5);
    Kinetic.Kman(16)=Kman(6);


    % High mannose
    e=9999;
    KH=[1,1,1];
    for i=1:10
        x0=rand(1,6).*3000;
        xl=[max(100-Rhm),0,0]
        [KH0,e0]=HMPI(nac,man,100-Rhm,x0,xl)
        if e0<e
            e=e0;
            KH=KH0;
        end
    end
    Kinetic.KH(1)=KH(1);
    Kinetic.KH(2)=KH(2);
    Kinetic.KH(3)=KH(3);
    
    

end









