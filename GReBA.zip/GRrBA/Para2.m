%Glycosylation Model Parameter identification 
%Liang Zhang, KTH, April, 2019
%This function is used for the parameter identification for the second part
function [Kinetic] = Para2(Sugar,Glyco,Kinetic)

    %The concentration of galactose, mannose, and galactose
    Cman=Sugar(:,1); %the average concentration of sugar in the pseudo-perfusion culture
    Cgal=Sugar(:,2); %the average concentration of sugar in the pseudo-perfusion culture
    Cglc=Sugar(:,3); %the average concentration of sugar in the pseudo-perfusion culture

    %the glycosylation patterns from experimental data
    RG12F=Glyco(:,1);  RG1F=Glyco(:,2);  RG2F=Glyco(:,3);
    RG0F=Glyco(:,4);  RG0=Glyco(:,5);  RG1=Glyco(:,6);
    RGF=RG12F+RG0F; Rhm=Glyco(:,7)+Glyco(:,8); RM5=Glyco(:,7);
    RM6=Glyco(:,8); RG0FNN=Glyco(:,9); RG0FN=Glyco(:,10); RG0N=Glyco(:,11);
    Run=Glyco(:,12);

    %% Parameter identificaiton
    % for PG12F
    e=9999;
    KG12F=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*50;
        xl=[max(RG12F(1:6)),0,0,max(RG12F(7:12)),0,0];
        [KG12F0,e0]=MNtoG(Cman,Cgal,RG12F,x0,xl)
        if e0<e
            e=e0;
            KG12F=KG12F0;
        end
    end
    Kinetic.KG(1)=KG12F(1);
    Kinetic.KG(2)=KG12F(2);
    Kinetic.KG(4)=KG12F(3);
    Kinetic.KG(6)=KG12F(4);
    Kinetic.KG(7)=KG12F(5);
    Kinetic.KG(9)=KG12F(6);
    
    % for PG2F
    e=9999;
    KG2F=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*8;
        xl=[max(RG2F(1:6)),0,0,max(RG2F(7:12)),0,0];
        [KG2F0,e0]=MNtoG(Cman,Cgal,RG2F,x0,xl);
        if e0<e
            e=e0;
            KG2F=KG2F0;
        end
    end
    Kinetic.KG(16)=KG2F(1);
    Kinetic.KG(17)=KG2F(2);
    Kinetic.KG(19)=KG2F(3);
    Kinetic.KG(21)=KG2F(4);
    Kinetic.KG(22)=KG2F(5);
    Kinetic.KG(24)=KG2F(6);
    
    
    % for PG1
    e=9999;
    KG1=[1,1,1,1,1,1];
    for i=1:10
        x0=rand(1,6).*10;
        xl=[max(RG1(1:6)),0,0,max(RG1(7:12)),0,0];
        [KG10,e0]=MNtoG(Cman,Cgal,RG1,x0,xl);
        if e0<e
            e=e0;
            KG1=KG10;
        end
    end
    Kinetic.KG(31)=KG1(1);
    Kinetic.KG(32)=KG1(2);
    Kinetic.KG(34)=KG1(3);
    Kinetic.KG(36)=KG1(4);
    Kinetic.KG(37)=KG1(5);
    Kinetic.KG(39)=KG1(6);
    
end


