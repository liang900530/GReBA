function [x,e] =HMPI(x1,x2,y,x0,xl)

fun=@(p) p(1).*x1./(p(2)+x1).*p(3)./(p(3)+x2)-y;
options = optimoptions('lsqnonlin','Display','iter');

[x,e] = lsqnonlin(fun,x0,xl);

end
