%Glycosylation Model Part I 
%Liang Zhang, KTH, 2019
%This part of the model link the feeding carbon source in the medium to the
%glycan components: Fuc,Man,GlcNAc,Gal

%The synthesis of GCP_Fucose, which are from glc,man and gal respectively

%Kifucglcman means the inhibition effect of mannose on GCPfuc which is
%synthesized from glucose
%This part has exclude the high mannose and unassigned glycoform
function [GCPfuc] = fuc(Cman, Cgal, Cglc, Kfuc)
%The maxium reaction rate:
GCPfucmaxglc=Kfuc(1);
GCPfucmaxman=Kfuc(2);
GCPfucmaxgal=Kfuc(3);

%The saturation kinetic parameter
Ksfucglc=Kfuc(6);
Ksfucman=Kfuc(7);
Ksfucgal=Kfuc(8);

%The Inhibition kinetic parameter
Kifucglcman=Kfuc(11);
Kifucglcgal=Kfuc(12);
Kifucmanglc=Kfuc(13);
Kifucmangal=Kfuc(14);
Kifucgalglc=Kfuc(15);
Kifucgalman=Kfuc(16);

%GCP_fucose from glucose. Mannose and galacose have the inhibition effect:
GCPfuc_glc=GCPfucmaxglc.*Cglc./(Cglc+Ksfucglc); 
%GCP_fucose from mannose. Glucose and galacose have the inhibition effect:
GCPfuc_man=GCPfucmaxman.*Cman./(Cman+Ksfucman+Cgal.*Ksfucman./Kifucmangal);
%GCP_fucose from galactose. Mannose and glucose have the inhibition effect:
GCPfuc_gal=GCPfucmaxgal.*Cgal./(Cgal+Ksfucgal+Cman.*Ksfucgal./Kifucgalman);
%Total amount of GCP_fucose
Judge=GCPfuc_glc+GCPfuc_man+GCPfuc_gal;
if Judge>100
    GCPfuc=100;
else
    GCPfuc=GCPfuc_glc+GCPfuc_man+GCPfuc_gal;
end

end